package com.example.esalaf;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class UserDB extends DbConnexion<User>{


    public UserDB() throws SQLException {
        super();
    }

    @Override
    public void save(User object) throws SQLException {

    }
    public boolean authenticate(String email, String password) throws SQLException {
        String req = "SELECT * FROM admin WHERE email = ? AND password = ?";
        PreparedStatement stmt = connection.prepareStatement(req);
        stmt.setString(1, email);
        stmt.setString(2, password);
        ResultSet rs = stmt.executeQuery();
        return rs.next();
    }

    public void sav(User object) throws SQLException {

        String req = "insert into admin (nom , prenom , email , password) values (? , ? , ? , ?) ;";


        this.preparedStatement = this.connection.prepareStatement(req);

        this.preparedStatement.setString(1 , object.getNom());
        this.preparedStatement.setString(2 , object.getPrenom());
        this.preparedStatement.setString(3 , object.getEmail());
        this.preparedStatement.setString(4 , object.getPassword());


        this.preparedStatement.execute();

    }

    @Override
    public void update(User object) throws SQLException {
        String req = "UPDATE admin SET nom='" + object.getNom() + "', prenom='" + object.getPrenom() +  "', email='" + object.getEmail()+ "', password='" + object.getPassword()  +"' WHERE id_user='" + object.getId_user() + "'";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.execute();
    }

    @Override
    public void delete(User object) throws SQLException {
        String req = "DELETE FROM admin WHERE `admin`.`id_user` = '" + object.getId_user() + "'";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.execute();
    }

    @Override
    public User getOne(Long id) throws SQLException {
        return null;
    }

    @Override
    public List<User> getAll() throws SQLException {
        List<User> mylist = new ArrayList<User>();
        String req = " select * from admin" ;


        this.statement= this.connection.createStatement();

        this.resultSet =  this.statement.executeQuery(req);

        while (this.resultSet.next()){

            mylist.add( new User(this.resultSet.getLong(1) , this.resultSet.getString(2),
                    this.resultSet.getString(3), this.resultSet.getString(4) , this.resultSet.getString(5)));
        }
        return mylist;
    }

}
