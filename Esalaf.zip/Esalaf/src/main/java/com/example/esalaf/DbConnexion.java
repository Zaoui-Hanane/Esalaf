package com.example.esalaf;
import java.sql.*;
import java.util.List;

public abstract class DbConnexion<T> {
    protected Connection connection ;
    protected  Statement statement ;
    protected PreparedStatement preparedStatement ;
    protected ResultSet resultSet ;

    private String url = "jdbc:mysql://127.0.0.1:3306/esalaf" ;

    private String login = "root";

    private String password = "";

    public DbConnexion() throws SQLException {

        this.connection = DriverManager.getConnection(url , login , password);

    }

    public abstract void save(T object)throws SQLException ;

    public abstract void update(T object) throws SQLException;

    public abstract void delete(T object) throws SQLException;


    public abstract T getOne(Long id) throws SQLException;


    public abstract List<T> getAll() throws SQLException;


}
