package com.example.esalaf;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class AdminSceneController implements Initializable {
    @FXML
    private TextField nom;

    @FXML
    private TextField search;
    @FXML
    private TextField prenom;

    @FXML
    private TextField email;
    @FXML
    private TextField password;
    @FXML
    private TableView<User> mytab;

    @FXML
    private TableColumn<User, Long> col_id;

    @FXML
    private TableColumn<User, String> col_nom;

    @FXML
    private TableColumn<User, String> col_pre;
    @FXML
    private TableColumn<User, String> col_email;

    @FXML
    private int index;

    @FXML
    public  Long Index;
    @FXML
    protected void onSaveButtonClick(){

        User cli = new User(0l , nom.getText() , prenom.getText(),email.getText(),password.getText());

        try {
            UserDB clidao = new UserDB();

            clidao.sav(cli);



        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        UpdateTable();

    }



    public void UpdateTable(){
        col_id.setCellValueFactory(new PropertyValueFactory<User,Long>("id_user"));
        col_nom.setCellValueFactory(new PropertyValueFactory<User,String>("nom"));
        col_pre.setCellValueFactory(new PropertyValueFactory<User,String>("prenom"));
        col_email.setCellValueFactory(new PropertyValueFactory<User,String>("email"));

        mytab.setItems(getUserData());


        //search bar
        FilteredList<User> filteredData = new FilteredList<>(getUserData(), b-> true);
        search.textProperty().addListener((observable , oldValue , newValue)->{
            filteredData.setPredicate(Credit -> {
                if (newValue.isEmpty() || newValue.isBlank() || newValue == null){
                    return true;
                }
                String searchKey = newValue.toLowerCase();
                if(Credit.getNom().toLowerCase().indexOf(searchKey) > -1){
                    return true;
                }else
                    return false;
            });

        });
        SortedList<User> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(mytab.comparatorProperty());
        mytab.setItems(sortedData);
    }

    public static ObservableList<User> getUserData(){

        UserDB clidao = null;

        ObservableList<User> listfx = FXCollections.observableArrayList();

        try {
            clidao = new UserDB();
            for(User ettemp : clidao.getAll())
                listfx.add(ettemp);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx ;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();
    }


    public void getItem(MouseEvent event){
        index = mytab.getSelectionModel().getSelectedIndex();
        if (index < -1){
            return ;
        }
        nom.setText(col_nom.getCellData(index));
        prenom.setText(col_pre.getCellData(index));
        email.setText(col_email.getCellData(index));

    }
    public void onUpdateButtonClick(){
        index = mytab.getSelectionModel().getSelectedIndex();
        User c1 = new User();

        c1.setNom(nom.getText());
        c1.setPrenom(prenom.getText());
        c1.setEmail(email.getText());
        c1.setPassword(password.getText());
        Index = (long) index +1;
        c1.setId_user(Index);
        try
        {
            UserDB clidao = new UserDB();
            clidao.update(c1);
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
        UpdateTable();
    }

    public void onDeleteButtonClick(){
        index = mytab.getSelectionModel().getSelectedIndex();
        User c1 = new User();

        c1.setNom(nom.getText());
        c1.setPrenom(prenom.getText());
        c1.setEmail(email.getText());
        Index = (long) index +1;
        c1.setId_user(Index);
        try
        {
            UserDB clidao = new UserDB();
            clidao.delete(c1);
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
        UpdateTable();
    }

    public void switchToClient(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("sceneMenu.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToAdmin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("adminScene.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToCredit(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Credit.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToHome(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Admin.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToPayment(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("payment.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

}