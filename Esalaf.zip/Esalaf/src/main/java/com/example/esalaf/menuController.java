package com.example.esalaf;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class menuController  implements Initializable {
    @FXML
    private TextField nom;
    @FXML
    private TextField search;
    @FXML
    private TextField tele;


    @FXML
    private TableView<Client> mytab;

    @FXML
    private TableColumn<Client, Long> col_id;

    @FXML
    private TableColumn<Client, String> col_nom;

    @FXML
    private TableColumn<Client, String> col_tele;
    @FXML
    private int index;

    @FXML
    public  Long Index;
    @FXML
    protected void onSaveButtonClick(){

        Client cli = new Client(0l , nom.getText() , tele.getText());

        try {
            ClientDB clidao = new ClientDB();

            clidao.save(cli);



        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        UpdateTable();

    }



    public void UpdateTable(){
        col_id.setCellValueFactory(new PropertyValueFactory<Client,Long>("id_client"));
        col_nom.setCellValueFactory(new PropertyValueFactory<Client,String>("nom"));
        col_tele.setCellValueFactory(new PropertyValueFactory<Client,String>("telepehone"));
        mytab.setItems(getDataClients());

        //search bar
        FilteredList<Client> filteredData = new FilteredList<>(getDataClients(), b-> true);
        search.textProperty().addListener((observable , oldValue , newValue)->{
            filteredData.setPredicate(Credit -> {
                if (newValue.isEmpty() || newValue.isBlank() || newValue == null){
                    return true;
                }
                String searchKey = newValue.toLowerCase();
                if(Credit.getNom().toLowerCase().indexOf(searchKey) > -1){
                    return true;
                }else
                    return false;
            });

        });
        SortedList<Client> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(mytab.comparatorProperty());
        mytab.setItems(sortedData);
    }


    public static ObservableList<Client> getDataClients(){

        ClientDB clidao = null;

        ObservableList<Client> listfx = FXCollections.observableArrayList();

        try {
            clidao = new ClientDB();
            for(Client ettemp : clidao.getAll())
                listfx.add(ettemp);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx ;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();
    }

   public void getItem(MouseEvent event){
        index = mytab.getSelectionModel().getSelectedIndex();
        if (index < -1){
            return ;
        }
        nom.setText(col_nom.getCellData(index));
        tele.setText(col_tele.getCellData(index));

    }

    public void onUpdateButtonClick(){
        index = mytab.getSelectionModel().getSelectedIndex();
        Client c1 = new Client();

            c1.setNom(nom.getText());
            c1.setTelepehone(tele.getText());
             Index = (long) index +1;
            c1.setId_client(Index);
            try
            {
                ClientDB clidao = new ClientDB();
                clidao.update(c1);
            }
            catch (SQLException e) {
                throw new RuntimeException(e);
            }
        UpdateTable();
        }
    public void onDeleteButtonClick(){
        index = mytab.getSelectionModel().getSelectedIndex();
        Client c1 = new Client();

        c1.setNom(nom.getText());
        c1.setTelepehone(tele.getText());
        Index = (long) index + 1;
        c1.setId_client(Index);
        try
        {
            ClientDB clidao = new ClientDB();
            clidao.delete(c1);
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
        UpdateTable();
    }

    public void switchToClient(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("sceneMenu.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToAdmin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("adminScene.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToCredit(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Credit.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToHome(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Admin.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToPayment(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("payment.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}