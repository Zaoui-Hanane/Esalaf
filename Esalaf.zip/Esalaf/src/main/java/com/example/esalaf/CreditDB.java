package com.example.esalaf;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CreditDB extends DbConnexion<Credit>{

    public CreditDB() throws SQLException {
        super();
    }

    @Override
    public void save(Credit object) throws SQLException {
        String req = "INSERT INTO `credit` ( `nom_client`, `produit`, `prix`, `quantite`, `date_credit`) VALUES ( ?, ?, ?, ?, ?);";


        this.preparedStatement = this.connection.prepareStatement(req);

        this.preparedStatement.setString(1, object.getNom());
        this.preparedStatement.setString(2 , object.getProduit());
        this.preparedStatement.setDouble(3 , object.getPrix_produit());
        this.preparedStatement.setInt(4 , object.getQuant_produit());
        this.preparedStatement.setString(5 , object.getDate_credit());


        this.preparedStatement.execute();
    }

    @Override
    public void update(Credit object) throws SQLException {
        String req = "UPDATE credit SET nom_client='" + object.getNom() + "', produit='" + object.getProduit() +  "', prix='" + object.getPrix_produit()+ "', quantite='" + object.getQuant_produit() + "', date_credit='" + object.getDate_credit()  +"' WHERE id_credit='" + object.getId_credit() + "'";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.execute();
    }

    @Override
    public void delete(Credit object) throws SQLException {
        String req = "DELETE FROM credit WHERE `credit`.`id_credit` = '" + object.getId_credit() + "'";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.execute();
    }

    @Override
    public Credit getOne(Long id) throws SQLException {
        return null;
    }

    @Override
    public List<Credit> getAll() throws SQLException {
        List<Credit> mylist = new ArrayList<Credit>();
        String req = " select * from credit" ;


        this.statement= this.connection.createStatement();

        this.resultSet =  this.statement.executeQuery(req);

        while (this.resultSet.next()){

            mylist.add(new Credit(
                    this.resultSet.getLong(1),
                    this.resultSet.getString(2),
                    this.resultSet.getString(3),
                    this.resultSet.getDouble(4),
                    this.resultSet.getInt(5),
                    this.resultSet.getString(6)
            ));

        }
        return mylist;
    }
}
