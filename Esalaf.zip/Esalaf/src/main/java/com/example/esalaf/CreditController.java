package com.example.esalaf;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class CreditController implements Initializable {

    @FXML
    private TableColumn<Credit, Long> col_id;

    @FXML
    private TextField search;
    @FXML
    private TextField nom;

    @FXML
    private TextField produit;

    @FXML
    private TextField prix_produit;
    @FXML
    private TextField quant;
    @FXML
    private TextField date_credit;
    @FXML
    private TableView<Credit> mytab;



    @FXML
    private TableColumn<Credit, String> col_nom;

    @FXML
    private TableColumn<Credit, String> col_produit;
    @FXML
    private TableColumn<Credit, Double> col_prix;
    @FXML
    private TableColumn<Credit, Integer> col_quant;
    @FXML
    private TableColumn<Credit, String> col_dateCredit;
    @FXML
    private int index;

    @FXML
    public  Long Index;

    @FXML
    protected void onSaveButtonClick(){
        double prixValue = Double.parseDouble(prix_produit.getText());
        int qnt = Integer.parseInt(quant.getText());

        Credit cli = new Credit(0l ,nom.getText() , produit.getText(),prixValue,qnt,date_credit.getText());

        try {
            CreditDB clidao = new CreditDB();

            clidao.save(cli);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        UpdateTable();

    }
    public void UpdateTable(){
        col_id.setCellValueFactory(new PropertyValueFactory<Credit,Long>("id_credit"));
        col_nom.setCellValueFactory(new PropertyValueFactory<Credit,String>("nom"));
        col_produit.setCellValueFactory(new PropertyValueFactory<Credit,String>("produit"));
        col_prix.setCellValueFactory(new PropertyValueFactory<Credit,Double>("prix_produit"));
        col_quant.setCellValueFactory(new PropertyValueFactory<Credit,Integer>("quant_produit"));
        col_dateCredit.setCellValueFactory(new PropertyValueFactory<Credit,String>("date_credit"));
        mytab.setItems(getCreditData());

        //search bar
        FilteredList<Credit> filteredData = new FilteredList<>(getCreditData(), b-> true);
        search.textProperty().addListener((observable , oldValue , newValue)->{
            filteredData.setPredicate(Credit -> {
                if (newValue.isEmpty() || newValue.isBlank() || newValue == null){
                    return true;
                }
                String searchKey = newValue.toLowerCase();
                if(Credit.getNom().toLowerCase().indexOf(searchKey) > -1){
                    return true;
                }else
                    return false;
            });

        });
        SortedList<Credit> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(mytab.comparatorProperty());
        mytab.setItems(sortedData);
    }

    public static ObservableList<Credit> getCreditData(){

        CreditDB clidao = null;

        ObservableList<Credit> listfx = FXCollections.observableArrayList();

        try {
            clidao = new CreditDB();
            for(Credit ettemp : clidao.getAll())
                listfx.add(ettemp);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


        return listfx;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();
    }

    public void getItem(MouseEvent event){
        index = mytab.getSelectionModel().getSelectedIndex();
        if (index < -1){
            return ;
        }
        nom.setText(col_nom.getCellData(index));
        produit.setText(col_produit.getCellData(index));
        String prixAsString = col_prix.getCellData(index).toString();

        prix_produit.setText(prixAsString);
        String quantt = col_quant.getCellData(index).toString();
        quant.setText(quantt);
        date_credit.setText(col_dateCredit.getCellData(index));
    }
    public void onUpdateButtonClick(){
        index = mytab.getSelectionModel().getSelectedIndex();
        Credit c1 = new Credit();

        c1.setNom(nom.getText());
        c1.setProduit(produit.getText());
        double prixValue = Double.parseDouble(prix_produit.getText());
        int qnt = Integer.parseInt(quant.getText());
        c1.setPrix_produit(prixValue);
        c1.setQuant_produit(qnt);
        c1.setDate_credit(date_credit.getText());
        Index = (long) index +1;
        c1.setId_credit(Index);
        try
        {
            CreditDB clidao = new CreditDB();
            clidao.update(c1);
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
        UpdateTable();
    }

    public void onDeleteButtonClick(){
        index = mytab.getSelectionModel().getSelectedIndex();
        Credit c1 = new Credit();

        c1.setNom(nom.getText());
        c1.setProduit(produit.getText());
        double prixValue = Double.parseDouble(prix_produit.getText());
        int qnt = Integer.parseInt(quant.getText());
        c1.setPrix_produit(prixValue);
        c1.setQuant_produit(qnt);
        c1.setDate_credit(date_credit.getText());
        Index = (long) index +1;
        c1.setId_credit(Index);
        try
        {
            CreditDB clidao = new CreditDB();
            clidao.delete(c1);
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
        UpdateTable();
    }

    public void switchToClient(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("sceneMenu.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToAdmin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("adminScene.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToCredit(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Credit.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToPayment(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("payment.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToHome(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Admin.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}