package com.example.esalaf;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PaymentDB extends DbConnexion<Payment>{

    public PaymentDB() throws SQLException {
        super();
    }

    @Override
    public void save(Payment object) throws SQLException {

    }

    @Override
    public void update(Payment object) throws SQLException {
        String req = "UPDATE payment SET nom_client='" + object.getNom() + "', montantTotal='" + object.getMontantTotal()+ "', montantPaye='" + object.getMontantPaye() + "' WHERE nom_client='" + object.getNom() + "'";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.execute();
    }

    @Override
    public void delete(Payment object) throws SQLException {

    }

    @Override
    public Payment getOne(Long id) throws SQLException {
        return null;
    }

    public Payment getOneByNom(String nom) throws SQLException {
        String req = "SELECT * FROM `payment` WHERE nom_client = '" + nom + "'";

        this.statement = this.connection.createStatement();
        this.resultSet = this.statement.executeQuery(req);

        Payment p1 = null;
        if (this.resultSet.next()) {
            p1 = new Payment(this.resultSet.getLong(1), this.resultSet.getString(2),
                    this.resultSet.getDouble(3), this.resultSet.getDouble(4));
        }
        return p1;
    }

    @Override
    public List<Payment> getAll() throws SQLException {
        List<Payment> mylist = new ArrayList<Payment>();
        String req = " select * from payment" ;


        this.statement = this.connection.createStatement();

        this.resultSet =  this.statement.executeQuery(req);

        while (this.resultSet.next()){

            mylist.add( new Payment(this.resultSet.getLong(1) , this.resultSet.getString(2),
                    this.resultSet.getDouble(3), this.resultSet.getDouble(4)));
        }
        return mylist;
    }

}
