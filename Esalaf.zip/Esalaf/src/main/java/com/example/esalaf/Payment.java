package com.example.esalaf;

public class Payment {

    private Long id_payment ;
    private String nom ;
    private double montantTotal;
    private double montantPaye;

    public Payment() {
    }

    public Payment(Long id_payment, String nom, double montantTotal, double montantPaye) {
        this.id_payment = id_payment;
        this.nom = nom;
        this.montantTotal = montantTotal;
        this.montantPaye = montantPaye;
    }

    public Long getId_payment() {
        return id_payment;
    }

    public void setId_payment(Long id_payment) {
        this.id_payment = id_payment;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public double getMontantTotal() {
        return montantTotal;
    }

    public void setMontantTotal(double montantTotal) {
        this.montantTotal = montantTotal;
    }

    public double getMontantPaye() {
        return montantPaye;
    }

    public void setMontantPaye(double montantPaye) {
        this.montantPaye = montantPaye;
    }

    @Override
    public String toString() {
        return "Payment{" +
                "id_payment=" + id_payment +
                ", nom='" + nom + '\'' +
                ", montantTotal=" + montantTotal +
                ", montantPaye=" + montantPaye +
                '}';
    }
    public void Payer(double montantPaye){
        this.montantPaye = this.montantPaye + montantPaye;
    }
}
