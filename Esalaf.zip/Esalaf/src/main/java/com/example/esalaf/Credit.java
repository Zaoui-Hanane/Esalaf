package com.example.esalaf;

import java.util.Date;

public class Credit {
    private Long id_credit ;
    private String nom ;
    private String produit ;
    private double  prix_produit ;
    private int quant_produit ;
    private String date_credit ;

    public Credit() {
    }

    public Credit(Long id_credit, String nom, String produit, double prix_produit, int quant_produit, String date_credit) {
        this.id_credit = id_credit;
        this.nom = nom;
        this.produit = produit;
        this.prix_produit = prix_produit;
        this.quant_produit = quant_produit;
        this.date_credit = date_credit;
    }

    public Long getId_credit() {
        return id_credit;
    }

    public void setId_credit(Long id_credit) {
        this.id_credit = id_credit;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getProduit() {
        return produit;
    }

    public void setProduit(String produit) {
        this.produit = produit;
    }

    public double getPrix_produit() {
        return prix_produit;
    }

    public void setPrix_produit(double prix_produit) {
        this.prix_produit = prix_produit;
    }

    public int getQuant_produit() {
        return quant_produit;
    }

    public void setQuant_produit(int quant_produit) {
        this.quant_produit = quant_produit;
    }

    public String getDate_credit() {
        return date_credit;
    }

    public void setDate_credit(String date_credit) {
        this.date_credit = date_credit;
    }

    @Override
    public String toString() {
        return "Credit{" +
                "id_credit=" + id_credit +
                ", nom='" + nom + '\'' +
                ", produit='" + produit + '\'' +
                ", prix_produit=" + prix_produit +
                ", quant_produit=" + quant_produit +
                ", date_credit='" + date_credit + '\'' +
                '}';
    }
}
