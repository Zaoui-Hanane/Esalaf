package com.example.esalaf;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.EventObject;

public class loginController {
 @FXML
    private Label label1;
 @FXML
    private TextField email;
 @FXML
    private PasswordField password;

 public void loginButtonAction(ActionEvent e) throws SQLException {

     if (email.getText().isBlank() == false && password.getText().isBlank() == false){
         //label1.setText("you try");
         validateLogin();
     }else {
         label1.setText("Entrez l'email et le mot de passe.");
     }
 }
 public void validateLogin() throws SQLException {
     UserDB use = new UserDB();
     try {
         if(use.authenticate(email.getText(),password.getText()) == true){
             FXMLLoader loader = new FXMLLoader(getClass().getResource("Admin.fxml"));
             Parent root = loader.load();
             Scene scene = new Scene(root);
             Stage stage = (Stage) email.getScene().getWindow();
             stage.setScene(scene);
             stage.show();

         }else{
             label1.setText("Email ou Mot de passe invalid.");
         }

     }catch (Exception e){
         e.printStackTrace();
     }
    }


}