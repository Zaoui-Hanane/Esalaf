package com.example.esalaf;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class PaymentController implements  Initializable {
    @FXML
    private TableColumn<Payment, Long> col_id;
    @FXML
    private TableView<Payment> mytab;
    @FXML
    private TableColumn<Payment, String> col_nom;
    @FXML
    private TableColumn<Payment, Double> col_monTotal;
    @FXML
    private TableColumn<Payment, Double> col_paye;
    @FXML
    private TextField search;

    @FXML
    private TextField nomClient;
    @FXML
    private TextField montantPayer;
    @FXML
    private TextField nom_Client;
    @FXML
    private TextField montant_Payer;
    public void UpdateTable(){
        col_id.setCellValueFactory(new PropertyValueFactory<Payment,Long>("id_payment"));
        col_nom.setCellValueFactory(new PropertyValueFactory<Payment,String>("nom"));
        col_monTotal.setCellValueFactory(new PropertyValueFactory<Payment,Double>("montantTotal"));
        col_paye.setCellValueFactory(new PropertyValueFactory<Payment,Double>("montantPaye"));
        mytab.setItems(getCreditData());

        //search bar
        FilteredList<Payment> filteredData = new FilteredList<>(getCreditData(), b-> true);
        search.textProperty().addListener((observable , oldValue , newValue)->{
            filteredData.setPredicate(Credit -> {
                if (newValue.isEmpty() || newValue.isBlank() || newValue == null){
                    return true;
                }
                String searchKey = newValue.toLowerCase();
                if(Credit.getNom().toLowerCase().indexOf(searchKey) > -1){
                    return true;
                }else
                    return false;
            });

        });
        SortedList<Payment> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(mytab.comparatorProperty());
        mytab.setItems(sortedData);
    }

    public static ObservableList<Payment> getCreditData(){

        PaymentDB clidao = null;

        ObservableList<Payment> listfx = FXCollections.observableArrayList();

        try {
            clidao = new PaymentDB();
            for(Payment ettemp : clidao.getAll())
                listfx.add(ettemp);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


        return listfx;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();
    }

    public void switchToClient(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("sceneMenu.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToAdmin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("adminScene.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToHome(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Admin.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchToCredit(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Credit.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void switchToPayment(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("payment.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void onEffectuerPaymentClick(){
        String nom_client = nom_Client.getText();
        double montant_pay = Double.parseDouble(montant_Payer.getText());
        try{
            PaymentDB clidao = new PaymentDB();
            Payment P = new Payment();
            P = clidao.getOneByNom(nom_client);
            P.Payer(montant_pay);
            clidao.update(P);
            UpdateTable();
        }catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

}